package com.jeta.forms.store.jml;

public interface InlineJMLSerializer extends JMLSerializer {

	public String getObjectName();

}
