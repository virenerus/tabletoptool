1. To view the examples in the designer, open the project file examples.jfpr.
2. The forms subdirectory contains several example forms that can be viewed
   after the project is opened.  Forms in this directory are stored in both
   binary (.jfrm) and XML (.xml) to demonstrate the size/performance differences 
   between the two formats.

The image files used in these examples are copyrighted and cannot be
distributed without a license. If you wish to use these icons you must
purchase a license from http://www.iconexperience.com.
